function Calcular(){
	var peso = (document.convertidor.pesos.value);
	var dolar = (document.convertidor.cambio.value);
	var total = peso / dolar;

	document.convertidor.dolar.value = total;

}

function Limpiar(){
	document.convertidor.pesos.value = "";
	document.convertidor.dolar.value = "";
}