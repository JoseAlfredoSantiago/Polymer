console.log("Inicia el programa");


function myFunction(){
	console.log(this.myProperty);
}
myFunction();

var myObj = {
	myProperty = 15;
};

myFunction.call(myObj);
myFunction.apply(myObj);






console.log("Termina el programa");