function botones(){
	let contenedor = document.getElementByID('contenedor');
	let numero = document.getElementByID('rango').value;
	aleatorio = Math.floor(Math.random)
}